import "./App.css";
import Form from "./components/Form";

//call for "Form" (your jsx file name) within className="App"
function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Form />
      </header>
    </div>
  );
}

export default App;
